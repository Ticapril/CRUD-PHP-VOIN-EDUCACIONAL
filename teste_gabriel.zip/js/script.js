$('#form1').submit(function(event){
    //evitar o carregamento padrão
    event.preventDefault();

    // pegar as informações do frontend
    var nome = $('#nome').val();
    var cpf  = $('#cpf').val();
    var selectElem = document.getElementById('lista_cursos');
    var element = selectElem.selectedIndex;
    var curso  = $('#curso-' + element).val();
    //testando se funcionou
    console.log(element);

    $.ajax({
        url: 'http://localhost/teste_gabriel/alunos/inserir_alunos.php', //quem vai processar essa requisição
        method: 'POST', // o tipo de requisição enviando dados é POST
        data: {nome: nome, cpf: cpf, curso: curso}, //os dados em formato de objeto
        dataType: 'json' // o tipo de dado
    }).done(function(result){
        console.log(result);
    });
});



function getCursos(){
    $.ajax({
        url: 'http://localhost/teste_gabriel/cursos/buscar_cursos.php',
        method: 'GET',
        dataType: 'json'
    }).done(function(result){
        //adiociono a referencia do select em uma variavel
        mySelect = document.getElementById('lista_cursos');
        //crio o elemento e armazeno em uma variavel dinamicamente
        for (let index = 0; index < result.length; index++) {
            option = document.createElement("option");
            // option.setAttribute("id", `curso-${result[index].id_curso}`);
            // option.setAttribute("id", `curso-${result[index].id_curso}`);
            option.setAttribute("id", `curso-${result[index].id_curso - 1}`);
            // option.classList.add(`curso-${result[index].id_curso}`);
            // option.appendChild(document.createTextNode(`Codigo Curso - ${result[index].id_curso} - ${result[index].nome_curso}`));
            option.appendChild(document.createTextNode(result[index].id_curso));
            mySelect.appendChild(option);
        }
        option = document.querySelector("option");
        
    });
}
getCursos();